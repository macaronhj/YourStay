package yourstay.md.domain;

public class YourStay {

}
