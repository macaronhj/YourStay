package yourstay.md.mapper;

public interface YourstayMapper {

}
